package apigw

type Response struct {
	StatusCode int `json:"statusCode"`
}
